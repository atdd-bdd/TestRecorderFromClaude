package com.testrecorder.service;

public interface RunnerProvider {
    String getCurrentRunner();
}
